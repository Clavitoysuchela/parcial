import { useState } from "react";
import Countdown from "./Countdown";
import "./index.css";

function App() {
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [started, setStarted] = useState(false);

  const handleStart = () => {
    const total = hours * 3600 + minutes * 60 + seconds;
    if (total > 0) {
      setStarted(true);
    }
  };

  const handleCancel = () => {
    setHours(0);
    setMinutes(0);
    setSeconds(0);
  };

  if (started) {
    return <Countdown hours={hours} minutes={minutes} seconds={seconds} />;
  }

  return (
    <div className="timer-container">
      <h2 className="title">Cronometro</h2>
      <div className="line" />

      <div className="input-box">
        <div className="time-input">
          <span className="label">h</span>
          <input
            type="number"
            min="0"
            max="23"
            value={hours}
            onChange={(e) => setHours(Number(e.target.value))}
          />
        </div>
        <div className="time-input">
          <span className="label">m</span>
          <input
            type="number"
            min="0"
            max="59"
            value={minutes}
            onChange={(e) => setMinutes(Number(e.target.value))}
          />
        </div>
        <div className="time-input">
          <span className="label">s</span>
          <input
            type="number"
            min="0"
            max="59"
            value={seconds}
            onChange={(e) => setSeconds(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="controls">
        <button className="start" onClick={handleStart}>Iniciar</button>
        <button className="cancel" onClick={handleCancel}>Cancelar</button>
      </div>
    </div>
  );
}

export default App;
