import { useEffect, useState, useRef } from "react";
import beep from "./assets/Bee_2.mp3";

function Countdown({ hours, minutes, seconds }) {
  const totalTime = hours * 3600 + minutes * 60 + seconds; // tiempo original
  const [total, setTotal] = useState(totalTime);
  const [paused, setPaused] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    if (paused) return;

    const timer = setInterval(() => {
      setTotal((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          audioRef.current.play();
          audioRef.current.loop = true;
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [paused]);

  const h = String(Math.floor(total / 3600)).padStart(2, "0");
  const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");

  const handlePause = () => setPaused((p) => !p);
  const handleCancel = () => window.location.reload();

  const progress = ((totalTime - total) / totalTime) * 100;

  return (
  <div className="timer-container">
  <h2 className="title">Cronómetro</h2>
  <div className="line" />

  {/* Barra de progreso sobre los números */}
  <div className="progress-bar">
    <div className="progress" style={{ width: `${progress}%` }} />
  </div>

  <div className="display">{h}:{m}:{s}</div>

  <div className="controls">
    <button className="pause" onClick={handlePause}>
      {paused ? "Reanudar" : "Pausa"}
    </button>
    <button className="cancel" onClick={handleCancel}>Cancelar</button>
  </div>

  <audio ref={audioRef} src={beep} />
</div>
  );
}

export default Countdown;


