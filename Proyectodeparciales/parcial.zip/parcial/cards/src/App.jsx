import React from "react";
import ComponentGeneral from "./components/componenteGeneral";

function App() {
  return (
    <div className="App">
      <ComponentGeneral />
    </div>
  );
}

export default App;
