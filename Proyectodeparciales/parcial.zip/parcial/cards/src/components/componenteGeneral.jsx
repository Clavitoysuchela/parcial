import React, { useEffect, useState } from "react";
import ListaEstudiantes from "./listaEstudiantes";
import estudiantesData from "../data/estudiantes.json";

const ComponentGeneral = () => {
  const [estudiantes, setEstudiantes] = useState([]);

  useEffect(() => {
    setEstudiantes(estudiantesData);
  }, []);

  return <ListaEstudiantes estudiantes={estudiantes} />;
};

export default ComponentGeneral;
