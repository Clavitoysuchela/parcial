import React from "react";
import Estudiante from "./Estudiante";
import "./listaEstudiantes.css";

const ListaEstudiantes = ({ estudiantes }) => {
  return (
    <div className="lista-estudiantes">
      {estudiantes.map((estudiante) => (
        <Estudiante key={estudiante.id} estudiante={estudiante} />
      ))}
    </div>
  );
};

export default ListaEstudiantes;
