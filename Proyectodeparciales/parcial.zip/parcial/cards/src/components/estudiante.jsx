import React from "react";
import "./estudiante.css";

const Estudiante = ({ estudiante }) => {
  const { university, name, id, birthdate, address, barcode } = estudiante;

  return (
    <div className="id-card">
  <div className="card-content">
    {/* LADO IZQUIERDO */}
    <div className="left">
      <div className="header">
        <div className="university">{university}</div>
      </div>
      <div className="photo-name">
        <img
          src="https://i.imgur.com/8Km9tLL.jpg"
          alt={name}
          className="photo"
        />
      </div>
    </div>

    {/* LADO DERECHO */}
    <div className="right">
      <div className="info">
        <h2>{name}</h2>
        <p><strong>Student Id:</strong> {id}</p>
        <p><strong>Date:</strong> {birthdate}</p>
        <p><strong>Address:</strong> {address}</p>
      </div>
      <div className="barcode">
      <img
  src={`https://barcode.tec-it.com/barcode.ashx?data=${barcode}&code=Code128`}
  alt={`Código de barras de ${name}`}
/>

      </div>
    </div>
  </div>
</div>

  );
};

export default Estudiante;
